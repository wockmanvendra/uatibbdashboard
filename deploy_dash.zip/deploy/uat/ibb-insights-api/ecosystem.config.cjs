// PM2 process for the IBB Insights API (UAT).
//   pm2 start ecosystem.config.cjs     first time
//   pm2 reload ibb-insights-api        after copying a new build
// Settings come from .env in this folder (Node's --env-file, Node 20.6+).
module.exports = {
  apps: [
    {
      name: 'ibb-insights-api',
      cwd: __dirname,
      script: 'dist/src/server.js',
      node_args: '--env-file=.env',
      exec_mode: 'fork',
      instances: 1,
      autorestart: true,
      max_restarts: 20,
      restart_delay: 5000,
      max_memory_restart: '1G',
      time: true,
      out_file: 'logs/out.log',
      error_file: 'logs/error.log',
      merge_logs: true,
    },
  ],
};
